# [Loop]最大公约数

# Description

输入两个数，求这两个数的最大公约数。

# Input

两个整数a、b(1 <= a,b <= 100000)，中间用一个空格隔开。

# Output

a、b的最大公约数

# Sample Input
49 14

# Sample Output
7

# Hint
辗转相除法: https://zh.wikipedia.org/wiki/%E8%BC%BE%E8%BD%89%E7%9B%B8%E9%99%A4%E6%B3%95
