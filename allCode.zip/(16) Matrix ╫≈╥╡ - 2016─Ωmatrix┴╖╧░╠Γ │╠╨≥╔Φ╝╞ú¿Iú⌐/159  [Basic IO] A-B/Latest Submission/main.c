#include<stdio.h>
int main()	{
  int A = 0,B = 0;
  scanf("%d %d",&A,&B);
  int result = A - B;
  printf("%d\n",result);
  return 0;
}