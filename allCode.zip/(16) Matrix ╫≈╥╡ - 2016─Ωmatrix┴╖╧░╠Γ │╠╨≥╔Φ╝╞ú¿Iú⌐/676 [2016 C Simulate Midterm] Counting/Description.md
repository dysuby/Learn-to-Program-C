# [2016 C Simulate Midterm] Counting


Given an integer n, please count how many digits in N,and then add all digits.

## Example

### Input
```
123
```
### Output
```
3 6

```

### Input
```
2345
```
### Output
```
4 14
```

