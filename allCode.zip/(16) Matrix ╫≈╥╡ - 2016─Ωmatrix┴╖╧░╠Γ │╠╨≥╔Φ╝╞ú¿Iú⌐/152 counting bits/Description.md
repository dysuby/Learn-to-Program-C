# counting bits


Given a non negative integer number num. For every numbers i in the range 0 ≤ i ≤ num calculate the number of 1's in their binary representation and print them.

## input
5

## output
0,1,1,2,1,2