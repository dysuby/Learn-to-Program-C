# [C] Stack of Linked List

## Descrption
The stack in this exercise is implemented with linked list. You should implement
Three function push(), pop() and del().

1. Push: push a number in the stack.You should think about how to construct the
first node.
2. pop: pop the number witch is in the top of the stack, return it.If the stack
is empty return -1.And you should free the node of this number.
3. del:free the stack if it is not empty.

## Note

1. You should include stdio.h, malloc.h, Node.h in stack.h
2. format:You don't need to worry about the output format.

## Sample Input
```
5
1 2 3 4 5
6

```

## Sample Output
```
5 4 3 2 1 -1 

```

*From : 何翔*
