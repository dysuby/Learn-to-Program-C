#ifndef __NODE_H__
#define __NODE_H__

typedef struct Node {
    int num;
    struct Node* next;
} Node;

#endif

