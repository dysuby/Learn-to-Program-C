#ifndef __STACK_H__
#define __STACK_H__

#include <stdio.h>
#include <malloc.h>
#include "Node.h"
void push(Node **top, int n) {
    if (!(*top)) {  // 构造第一个节点
        // *top = (Node*)malloc(sizeof(Node));
        *top = (Node*)malloc(sizeof(Node));
        (*top)->num = n;
        (*top)->next = NULL;  // 栈底部元素的next为NULL，方便判断栈空的情况
        return;
    }
    // 构造后续节点
    // Node *temp = (Node*)malloc(sizeof(Node));
    Node *temp = (Node*)malloc(sizeof(Node));
    temp->next = *top;
    temp->num = n;
    *top = temp;
}

int pop(Node **top) {
    if (!(*top))  // 如果栈为空，返回-1
        return -1;
    // 顶部元素出栈，返回顶部元素的值
    Node *temp = *top;
    int pop_num = temp->num;
    *top = (*top)->next;
    free(temp);
    return pop_num;
}

void del(Node **top) {
    if (!(*top))  // 如果为空，直接返回
        return;

    Node *temp;
    while (*top) {
        temp = *top;
        *top = (*top)->next;
        free(temp);
    }
}

#endif
