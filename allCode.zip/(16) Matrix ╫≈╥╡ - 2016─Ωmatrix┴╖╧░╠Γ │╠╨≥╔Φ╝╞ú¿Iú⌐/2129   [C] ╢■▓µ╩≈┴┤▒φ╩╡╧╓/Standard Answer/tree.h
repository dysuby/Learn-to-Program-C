#ifndef __TREELL__
#define __TREELL__
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAXINDEX 50
typedef struct node {
    int x;
    struct node* left;
    struct node* right;
} BN;
void buildTree(BN** root) {
    BN forStyle = {1, NULL, NULL};
    int temp;
    BN** que[MAXINDEX];
    int head = 0;
    int tail = 1;
    que[0] = root;
    scanf("%d", &temp);
    while (temp != -1) {
        *que[head] = malloc(sizeof(forStyle));
        (*que[head])->x = temp;
        que[tail] = &((*que[head])->left);
        tail = (tail + 1) % MAXINDEX;
        que[tail] = &((*que[head])->right);
        tail = (tail + 1) % MAXINDEX;
        head = (head + 1) % MAXINDEX;
        scanf("%d", &temp);
    }
    while (head != tail) {
        *que[head] = NULL;
        head = (head + 1) % MAXINDEX;
    }
}
void outputTree(BN* root) {
    if (root != NULL) {
        outputTree(root->left);
        printf("%d ", root->x);
        outputTree(root->right);
    }
}
#endif
 