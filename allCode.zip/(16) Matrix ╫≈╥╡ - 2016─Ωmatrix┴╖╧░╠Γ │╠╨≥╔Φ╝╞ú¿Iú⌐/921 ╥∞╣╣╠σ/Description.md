# 异构体

# Description：

异构体是指两个字符串，有相同的字母组成，如果有不同的话仅有的不同点是字母的位置不一样。

例如：abcd和abcd，dcba，acdb都是异构体，但是abcd和abcde或qwer就不是异构体。

输入两个字符串（长度不超过50），判断这两个字符串是不是异构体，并且输出。如果是则输出YES，不是输出NO。

 

# Sample Input：
```
abcd bcda
```
 

# Sample Output：
```
YES
```
