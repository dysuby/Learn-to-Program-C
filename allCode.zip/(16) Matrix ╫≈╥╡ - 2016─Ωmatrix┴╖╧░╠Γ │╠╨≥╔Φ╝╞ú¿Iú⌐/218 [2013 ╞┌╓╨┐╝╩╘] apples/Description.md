# [2013 期中考试] apples

## Description:

One day Uncle Da travels to the countryside, where plants so many apple trees. He wanna pick some apples. Through he is very tall, he cannot pick up all the apples. Now you are given the height of Uncle Da, and the altitude of apples. Please compute how many apples he can pick.

input : 2 ints height and n(3<n<100), next line has n ints, the altitude of the apples.
output: one integer, the amount.

## example input:
```
	180 5
	170 180 190 299 100
```
## example output:
```
	3
```

chn: 
一天Uncle Da去乡下旅游，那里有py的苹果园，他想偷一些py的苹果。尽管他很高，但也不能摘到所有的苹果。假设他最多可以摘到相当于他身高高度的苹果，给出他的身高，以及若干苹果的高度，求出他可以摘到多少苹果。
