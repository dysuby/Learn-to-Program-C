# [2016 C Simulate Midterm] Leap Year

## Description
You are required to write a programm to figure out if the input year is a leap year.

## Input

The first line of the input stream is an integer n.
For the following n line there will be an integer for each line indicates a year, year(0 <= year <= 65535).


## Output

For each year, output "Yes" if it's a leap year, otherwise output "No".

## Sample Input

```
4
1
4
100
400
```

## Sample Output

```
No
Yes
No
Yes
```