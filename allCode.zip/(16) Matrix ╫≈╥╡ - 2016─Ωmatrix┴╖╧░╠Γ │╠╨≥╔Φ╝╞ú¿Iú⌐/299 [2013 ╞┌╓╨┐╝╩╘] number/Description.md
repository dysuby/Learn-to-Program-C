# [2013 期中考试] number

## Description:

There is a sequence of numbers : b(i), from 2 on, b(i) = b(i-1) * b(i-2). You are given b(1), b(2) and n(3<n<100), please output b(n) % 10007;

input : 3 integers in a line, b1, b2, n;
output: only one integer bn%10007

example input:
```
2 3 4
```
example output:
```
18
```

chn:
定义一个数列b[i], 从第三项开始，每一项等于前两项的乘积，现在给出第一和第二项以及整数n，请你算出第n项mod 10007的结果。

 


## Hint:

no hint
