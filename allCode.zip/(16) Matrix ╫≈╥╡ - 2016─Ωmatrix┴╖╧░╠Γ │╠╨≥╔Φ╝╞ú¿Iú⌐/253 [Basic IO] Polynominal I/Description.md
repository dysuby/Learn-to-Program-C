# [Basic I/O] Polynominal I

# Description
Given two pair of integers (a1,b1) and (a2,b2),can you calculate the expanded form of (a1\*x+b1)\*(a2\*x+b2)?  
(note that we use "x^2" to express x\*x and omit "*")
 
# Input

Two line, each line contains a pair of integers ai and bi.(2<=ai,bi<=20)

# Output

One line,the expanded form of (a1\*x+b1)\*(a2\*x+b2).

# Sample Input

Copy sample input to clipboard

```
4 2
5 7
```

# Sample Output

```
20x^2+38x+14
```
