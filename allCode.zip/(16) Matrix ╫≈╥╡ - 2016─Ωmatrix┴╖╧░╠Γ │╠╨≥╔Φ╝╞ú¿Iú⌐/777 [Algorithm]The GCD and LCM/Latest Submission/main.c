#include <stdio.h>
int main() {
  int num1, num2, lcm = 0, gcd, max, min, test;
  int counter;
  scanf("%d%d", &num1, &num2);
  if (num1 > 0 && num2 > 0) {
    max = num1 >= num2 ? num1 : num2;
    min = num1 <= num2 ? num1 : num2;
    for (counter = 1; ; ++counter) {
      if (num1 % counter == 0 && num2 % counter == 0)
        gcd = counter;
      if (counter >= min)
        break;
    }
    for (counter = 1; ; ++counter) {
        test = max * counter;
        if (max % min == 0) {
          lcm = max;
          break;
        }
      }
    printf("%d %d\n", gcd, lcm);
  } else {
    printf("invalid\n");
  }
  return 0;
}