# [Algorithm]The GCD and LCM

# Description

Give you two integers, and calculate their GCD\(Greatest Common Divisor\) and LCM\(Least Common Multiple\). If both of them are positive, print the GCD and LCM. If some are invalid\(zero or negative\), print ``invalid``.

# Sample Input 1
```
2 10

```

# Sample Output 1
```
2 10

```

# Sample Input 2
```
14 0

```

# Sample Output 2

```
invalid

```

# Hint

You may not learn the algorithms of calculating LCM and GCD in your primary school or middle school. So you can serach about them, or read the instruction in wikipedia about [Least Common Multiple](https://en.wikipedia.org/wiki/Least_common_multiple) and [Greatest Common Divisor](https://en.wikipedia.org/wiki/Greatest_common_divisor).
