#include <stdio.h>

int GCD(int lhs, int rhs) {
  int gcd = 0;
  if (lhs && rhs) {
    while (lhs % rhs) {
      gcd = lhs % rhs;
      lhs = rhs;
      rhs = gcd;
    }
  }
  return rhs;
}

int main() {
  int left = 0, right = 0;
  scanf("%d%d", &left, &right);
  int gcd = GCD(left, right);
  if (left > 0 && right > 0) printf("%d %d\n", gcd, left * right / gcd);
  else puts("invalid");
}