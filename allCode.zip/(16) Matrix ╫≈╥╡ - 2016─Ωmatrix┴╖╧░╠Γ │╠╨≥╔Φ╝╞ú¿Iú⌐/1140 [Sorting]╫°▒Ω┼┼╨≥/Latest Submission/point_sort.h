#ifndef POINT_SORT_H
#define POINT_SORT_H


struct point {
	int x;
	int y;
};

void point_sort(struct point a[], int n);

#endif