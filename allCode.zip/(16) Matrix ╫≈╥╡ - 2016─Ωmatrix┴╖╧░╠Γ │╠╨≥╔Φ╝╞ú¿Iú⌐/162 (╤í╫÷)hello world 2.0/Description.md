# (选做)hello world 2.0

## Hello World! 2.0

现在想要一个程序，输入一个名字，则向这个人问好

## Input
Xiaoming

## output
Hello Xiaoming!

## input 
World

## output
Hello World!