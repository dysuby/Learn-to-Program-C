#include<stdlib.h>
 
int *doubleCapacity(int *list, int size, int addSize) {
        int *returnVal;
        returnVal = (int*)malloc(sizeof(int*)*(size+addSize));
        int i = 0;
        for (i = 0; i < (size+addSize); i++) {
                if (i < size) {
                        returnVal[i] = list[i];
                } else {
                        returnVal[i] = 0;
                }
        }
        return returnVal;
}