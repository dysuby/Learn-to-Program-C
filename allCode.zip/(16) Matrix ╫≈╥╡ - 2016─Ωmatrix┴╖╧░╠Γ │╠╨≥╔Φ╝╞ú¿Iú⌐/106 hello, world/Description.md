# hello, world

# Descrption

输出 hello, world


别忘了换行哦 ^_^

# Input

无

# Output
```
hello, world
```
# Hint
http://zh.wikipedia.org/wiki/Hello_World

http://en.wikipedia.org/wiki/%22Hello,_world!%22_program

