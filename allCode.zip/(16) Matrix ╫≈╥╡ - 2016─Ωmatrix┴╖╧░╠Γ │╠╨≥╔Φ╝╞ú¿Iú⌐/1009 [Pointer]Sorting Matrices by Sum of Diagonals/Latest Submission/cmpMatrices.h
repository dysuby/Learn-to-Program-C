#define MAX_TOTAL 10
#define MAX_SIZE 4
#define matrixIndex
void inputMatrices(int matrixArr[matrixIndex][][], size_t size);
void printMatrices(int matrixArr[matrixIndex][][], size_t size);
int cmpMatrices(const void *firstMatrixPtr, const void *secondMatrixPtr, void *sizePtr);
