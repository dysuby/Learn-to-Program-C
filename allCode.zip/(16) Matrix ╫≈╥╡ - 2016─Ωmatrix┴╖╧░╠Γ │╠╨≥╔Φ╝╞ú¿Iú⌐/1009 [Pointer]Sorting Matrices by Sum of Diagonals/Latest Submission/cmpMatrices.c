 #include "cmpMatrices.h"
#include <stdio.h>
void inputMatrices(int matrixArr[matrixIndex][][], size_t size) {
  int index1, index2;
  for (index2 = 0; index2 < (int)size; ++index2) {
    for (index1 = 0; index1 < (int)size; ++index1)
      scanf("%d", &matrixArr[matrixIndex][index2][index1]);
  }
}
void printMatrices(int matrixArr[matrixIndex][][], size_t size) {
  int index1, index2;
  for (index2 = 0; index2 < (int)size; ++index2) {
    for (index1 = 0; index1 < (int)size; ++index1)
      printf("%d", matrixArr[matrixIndex][index2][index1]);
  }
}
int cmpMatrices(const void *firstMatrixPtr, const void *secondMatrixPtr, void *sizePtr) {
  size_t *matrixSizePtr = (size_t *)sizePtr;
  size_t matrixSize = *matrixSizePtr;
  int firstMatrix[matrixSize][matrixSize] = (int) (*firstMatrixPtr) [matrixSize];
  int secondMatrix[matrixSize][matrixSize] = (int) (*secondMatrixPtr) [matrixSize];
  return 0;
}