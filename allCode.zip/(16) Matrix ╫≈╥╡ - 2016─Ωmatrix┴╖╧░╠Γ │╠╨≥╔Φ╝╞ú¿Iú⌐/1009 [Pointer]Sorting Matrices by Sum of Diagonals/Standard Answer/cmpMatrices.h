#ifndef CMPMATRICES_H
#define CMPMATRICES_H
#include <stdio.h>
#define MAX_TOTAL 10
#define MAX_SIZE 4
void inputMatrices(int (*matrix)[MAX_SIZE], size_t size);
int cmpMatrices(const void *firstPtr, const void *secondPtr, void *size);
void printMatrices(int (*matrix)[MAX_SIZE], size_t size);
#endif  // CMPMATRICES_H
