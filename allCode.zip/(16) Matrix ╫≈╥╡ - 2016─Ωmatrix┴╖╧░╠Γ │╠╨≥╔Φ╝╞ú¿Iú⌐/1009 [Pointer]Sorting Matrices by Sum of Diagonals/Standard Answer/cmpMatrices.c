#include <stdio.h>
#include <ctype.h>
#include "cmpMatrices.h"
int sumOfDialogs(int (*matrix)[MAX_SIZE], size_t size);
void inputMatrices(int (*matrix)[MAX_SIZE], size_t size) {
  for (size_t rowIndex = 0; rowIndex < size; ++rowIndex) {
    for (size_t colIndex = 0; colIndex < size; ++colIndex) {
      scanf("%d", &matrix[rowIndex][colIndex]);
    }
  }
}
int cmpMatrices(const void *firstMatrixPtr,
                const void *secondMatrixPtr,
                void *sizePtr) {
  // obtain firstMatrix from firstMatrixPtr for further comparison:
  // 1. what to compare are matrices of type <int [MAX_SIZE][MAX_SIZE]>
  // 2. but now we receive <const void> instead of <int [MAX_SIZE][MAX_SIZE]>
  // 3. so we should convert <const void> back to <int [MAX_SIZE][MAX_SIZE]>
  //    by casting the corresponding pointer's type before dereferencing it
  int (*firstMatrix)[MAX_SIZE] = *((int (*)[MAX_SIZE][MAX_SIZE])firstMatrixPtr);
  int (*secondMatrix)[MAX_SIZE] = *((int (*)[MAX_SIZE][MAX_SIZE])secondMatrixPtr);
  size_t size = *((size_t *)sizePtr);
  // comparision
  int firstSum = sumOfDialogs(firstMatrix, size),
      secondSum = sumOfDialogs(secondMatrix, size);
  if (firstSum < secondSum) {
    return -1;
  } else if (firstSum > secondSum) {
    return 1;
  } else {
    return 0;
  }
}
void printMatrices(int (*matrix)[MAX_SIZE], size_t size) {
  for (size_t rowIndex = 0; rowIndex < size; ++rowIndex) {
    printf("%d", matrix[rowIndex][0]);
    for (size_t colIndex = 1; colIndex < size; ++colIndex) {
      printf(" %d", matrix[rowIndex][colIndex]);
    }
    putchar('\n');
  }
  putchar('\n');
}
int sumOfDialogs(int (*matrix)[MAX_SIZE], size_t size) {
  int sum = 0;
  for (size_t rowIndex = 0; rowIndex < size; ++rowIndex) {
    for (size_t colIndex = 0; colIndex < size; ++colIndex) {
      if (rowIndex == colIndex || rowIndex + colIndex + 1 == size) {
        sum += matrix[rowIndex][colIndex];
      }
    }
  }
  return sum;
}
