#ifndef SIMPLE_OPERATOR
#define SIMPLE_OPERATOR

void add(char[], char[], char[]);

#endif