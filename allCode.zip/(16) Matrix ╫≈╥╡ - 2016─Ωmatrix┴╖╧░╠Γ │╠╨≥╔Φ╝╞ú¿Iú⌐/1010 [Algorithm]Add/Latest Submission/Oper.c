#include <string.h>
void add(char lhs[], char rhs[], char sum[]) {
  int l_len, r_len, cout = 0, ass[10], lindex, rindex, index = 0, sindex;
  l_len = strlen(lhs);
  r_len = strlen(rhs);
  for (lindex = l_len - 1, rindex = r_len - 1; rindex >= 0 && lindex >= 0; --lindex, --rindex) {
    ass[index] = (lhs[lindex] - '0' + rhs[rindex] - '0' + cout) % 10;
    cout = (lhs[lindex] - '0' + rhs[rindex] - '0' + cout) / 10;
    ++index;
  }
  while (rindex >= 0) {
    ass[index] = (rhs[rindex] - '0' + cout) % 10;
    cout = (rhs[rindex] - '0' + cout) / 10;
    --rindex;
    ++index;
  }
  while (lindex >= 0) {
    ass[index] = (lhs[rindex] - '0' + cout) % 10;
    cout = (lhs[lindex] - '0' + cout) / 10;
    --lindex;
    ++index;
  }
  if (cout != 0 && index < 10) {
    ass[index] = cout;
    ++index;
  }
  sindex = index;
  sum[sindex] = '\0';
  --sindex;
  for (index = 0; sindex >= 0; --sindex) {
    sum[sindex] = ass[index] + '0';
    ++index;
  }
}