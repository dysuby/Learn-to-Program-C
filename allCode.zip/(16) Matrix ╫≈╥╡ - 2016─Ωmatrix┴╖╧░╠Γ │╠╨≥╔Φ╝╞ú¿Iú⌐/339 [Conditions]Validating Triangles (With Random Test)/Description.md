# [Conditions]Validating Triangles (With Random Test)

# Description

Write a program that reads three edges for a triangle and determines whether the input is valid.
The input is valid if the sum of any two edges is greater than the third edge.

# Input

Three numbers a, b, c(seperated by one blank) which represent the edges of a triangle.
 
# Output

If valid, output valid, else output invalid.
 
# Sample Input

```
1 2 3
```

# Sample Output

```
invalid

```