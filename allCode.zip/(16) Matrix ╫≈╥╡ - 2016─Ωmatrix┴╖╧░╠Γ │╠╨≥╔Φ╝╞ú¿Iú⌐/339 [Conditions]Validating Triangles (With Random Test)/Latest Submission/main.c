#include <stdio.h>
int main()	{
	int a,b,c;
	scanf("%d%d%d",&a,&b,&c);
	if(a < b + c && b < a + c && c < a + b)	{
		printf("valid\n");
	}
	else	{
		printf("invalid\n");
	}
	return 0;
}