#include <stdio.h>
#include <string.h>
#include <assert.h>

char charmap[57] = {};

int main() {
  int char_num = 0, index = 0;
  char before = 0, after = 0;
  for (index = 0; index < 58; ++index) {
    charmap[index] = 'A' + index;
  }
  scanf("%d", &char_num);
  for (index = 0; index < char_num; ++index) {
    scanf(" %c %c", &before, &after);
    charmap[after - 'A'] = before;
  }
  char str[1001] = {};
  scanf("%s", str);
  // puts(str);
  int len = strlen(str);
  for (index = 0; index < len; ++index) {
    putchar(charmap[str[index] - 'A']);
  }
  putchar('\n');
}