# [Algorithm]Replace the Character

# Description
Double Eleven's Day is coming. Wang Xiaoming want to send some message to his girl friend. However, all his roommates are the SINGLE DOG. If they found Xiaoming was feeding dog food to them, they would kill HIM!!!  
At last, Xiaoming has a simple idea. He relpaces some characters of his message in a special pattern, and only his girl knows the pattern. So, Xiaoming's roommates can not know what the message is.  
Now, you must help Xiaoming's roommates using the pattern you known.  

# Input
The first is the total number ``N`` of characters will be replaced.  
Then the next N lines is the pattern which contains two the characters. The first is the character before repalcing, and the second is the character after replacing. And all the characters are alphabets. ('a' ~ 'z' and 'A' ~ 'Z')    
At the last line is the message after replacing consists of alphabets, whose length is less than 1000.  

# Output
print the message before replacing.  

# Sample Input
```plain
6 
o y
y i
i v
v e
e u
u o
vlyeuiyo

```

# Sample Output
```
iloveyou

```

# Explanation
From the sample input, we have:
```
  o -> y
  y -> i
  i -> v
  v -> e
  e -> u
  u -> o
```

And
```
  vlyeuiyo
  ^^^^^^^^
  ||||||||
  iloveyou
```

# Hint
Single Dogs enjoy coding...