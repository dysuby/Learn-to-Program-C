# [2016 C Midterm A] Calculate the day

# Description

Given the year, month, day, you're asked to answer how many day have passed in that year(including the day itself)?

## **For example, given 2000, 3, 3, the answer is 31+29+3.**

# Input

1. the first line is **n**, meaning the number of tests.

2. the next n line is input, with 3 number year, month, day in each line

# Ouput

output how many day have passed in that year(including the day itself), according to the input.

# Sample Input

```
4
4177 7 8
4152 1 1
3039 10 6
5567 7 14

```

# Sample Output

```
189
1
279
195

```