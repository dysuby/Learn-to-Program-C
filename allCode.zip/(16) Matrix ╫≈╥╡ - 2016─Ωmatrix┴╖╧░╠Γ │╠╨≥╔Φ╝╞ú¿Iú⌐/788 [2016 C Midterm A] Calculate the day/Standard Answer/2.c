#include <stdio.h>

int main() {
	int year, month, day, ans;
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d%d%d", &year, &month, &day);
		// 判断闰年
		int skip = (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
		ans = 0;
		// 不用数组只能一个一个加了
		for (int j = 1; j < month; j++) {
			if (j == 1 || j == 3 || j == 5 || j == 7 || j == 8
				|| j == 10 || j == 12) {
				ans += 31;
			} else if (j == 4 || j == 6 || j == 9 || j == 11) {
				ans += 30;
			} else {
				ans += skip ? 29 : 28;
			}
		}
		ans += day;
		printf("%d\n", ans);
	}
	return 0;
}