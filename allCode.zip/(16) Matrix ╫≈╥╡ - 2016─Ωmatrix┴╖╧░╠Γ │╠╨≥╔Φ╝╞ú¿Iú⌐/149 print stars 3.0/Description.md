# print stars 3.0

用户输入一个正整数，根据这个数字输出`*`图形

## Input
1

## Output
``
*
``
<hr>
## Input
2

## output
```
*
**
```
<hr>

## Input
3

## output
```
*
**
***
```
