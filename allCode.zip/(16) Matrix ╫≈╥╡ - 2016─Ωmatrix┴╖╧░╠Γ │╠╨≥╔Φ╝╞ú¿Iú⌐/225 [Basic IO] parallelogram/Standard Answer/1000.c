#include<stdio.h>
int main()
{
    char a;
    scanf("%c",&a);
    printf("   %c%c%c%c\n  %c%c%c%c\n %c%c%c%c\n%c%c%c%c\n",a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a);
    return 0;
 }
