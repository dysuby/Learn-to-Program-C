#include<stdio.h>
int main()	{
	char m;
	scanf("%c",&m);
	printf("   %c%c%c%c\n",m,m,m,m);
	printf("  %c%c%c%c\n",m,m,m,m);
	printf(" %c%c%c%c\n",m,m,m,m);
	printf("%c%c%c%c\n",m,m,m,m);
	return 0;
}