# [Basic I/O] parallelogram

# Description

读入一个字符，并用它输出一个平行四边形。

# input

一个字符

# output

一个大小为4的平行四边形，平行四边形每一行的开头会有0个或多个空格。

# Sample Input

```
#
```

# Sample Output

```
   ####
  ####
 ####
####
```