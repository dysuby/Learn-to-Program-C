void swapArray(int len, int arr1[len], int arr2[len]) {
  for (int i = 0; i < len; ++i) {
    int temp = arr1[i];
    arr1[i] = arr2[i];
    arr2[i] = temp;
  }
}

void swapMatrix(int len, int mat1[len][len], int mat2[len][len]) {
  for (int i = 0; i < len; ++i) {
    for (int j = 0; j < len; ++j) {
      int temp = mat1[i][j];
      mat1[i][j] = mat2[i][j];
      mat2[i][j] = temp;
    }
  }
}
