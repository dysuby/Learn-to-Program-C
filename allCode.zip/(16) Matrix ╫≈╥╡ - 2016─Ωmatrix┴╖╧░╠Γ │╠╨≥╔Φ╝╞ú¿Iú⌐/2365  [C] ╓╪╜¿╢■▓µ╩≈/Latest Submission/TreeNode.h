#ifndef TREE_NODE_H
#define TREE_NODE_H

typedef struct TreeNode {
 int val;
 struct TreeNode *left;
 struct TreeNode *right;
} TreeNode;
 

#endif