#include <stdio.h>
int main() {
  int caseNum = 0, size = 0, sum = 0, tmp = 0;
  for (scanf("%d", &caseNum); caseNum--; sum = 0) {
    scanf("%d", &size);
    for (int rowIndex = 0; rowIndex < size; ++rowIndex) {
      for (int colIndex = 0; colIndex < size; ++colIndex) {
        scanf("%d", &tmp);
        if (rowIndex == colIndex || rowIndex + colIndex + 1 == size) {
          sum += tmp;
        }
      }
    }
    printf("%d\n", sum);
  }
}
