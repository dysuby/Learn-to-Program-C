#include<stdio.h>
int main()	{
  int a;
  scanf("%d",&a);
  if (a == 0)
  printf("*\n**\n***\n**\n*\n");  
  else  if (a == 1)
  printf("@@@@@@@@\n@XXXXXX@\n@XXXXXX@\n@XXXXXX@\n@@@@@@@@\n");
    return 0;
}