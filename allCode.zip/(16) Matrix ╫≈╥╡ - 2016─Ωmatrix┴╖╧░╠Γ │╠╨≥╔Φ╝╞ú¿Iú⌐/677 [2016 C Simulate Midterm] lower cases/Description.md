# [2016 C Simulate Midterm] lower cases



Input a string which contains (a,b,c,...,z,A,B,C,...Z,\t and space ' ') and end of '\n',Please convert all the character into lower case and delete all the space and \t.(1 <= string length <= 20)
 

## Output format:
no '\n'

 

## For example:

[Input]
```
I L o  Ve       YoU
```
 

[Output]
```
iloveyou
```
-------------------------------------------

The input "I L o  Ve       YoU" means that:
```
I+' '+L+' '+o+' '+' '+V+e+'\t'+Y+o+U+'\n'
```