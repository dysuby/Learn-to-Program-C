# [Function]Easy String Function

# Description
You have already used some string functions, but do you know how they work ?

Now try to implement three of them by yourself.

1. strlen: return the length of a string
2. strcmp: compare two string a, b, the return value are as follow:
	* **0**:  if a == b
	* **positive integer**:  if a > b
	* **negative integer**:  if a < b
3. strcpy: copy b to a

## input
two string, a, b, their length are less than 100

## output
the length of a

the result of comparion between a and b

string a (after copy b to a)

## Hint
**You don't need to submit the main function.**

Your code should be like this:

```
int myStrlen(char a[]) {
	//todo
}

int myStrcmp(char a[], char b[]) {
	//todo
}

void myStrcpy(char des[], char src[]) {
	//todo
}
```

>**Note: Pay attention to '\0'**