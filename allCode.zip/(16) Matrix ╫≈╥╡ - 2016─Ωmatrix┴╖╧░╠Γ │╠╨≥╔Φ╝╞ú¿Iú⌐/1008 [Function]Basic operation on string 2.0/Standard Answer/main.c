#include <stdio.h>
#include <string.h>
#include "function.h"

#define SIZE 100

void get_input(char *str, char *del) {
    fgets(str, SIZE, stdin);
    str[strlen(str)-1] = '\0';
    *del = getchar();
    getchar();
}


int main () {
    char container[SIZE][SIZE] = {};
    char str[SIZE] = {}, del = 0;
    get_input(str, &del);
    int n = split(container, str, del);
    for (int i = 0; i < n; ++i) {
        printf("%s\n", container[i]);
    }
    get_input(str, &del);
    lstrip(str, del);
    printf("%s\n", str);
    rstrip(str, del);
    printf("%s\n", str);
    get_input(str, &del);
    strip(str, del);
    printf("%s\n", str);
    return 0;
}
