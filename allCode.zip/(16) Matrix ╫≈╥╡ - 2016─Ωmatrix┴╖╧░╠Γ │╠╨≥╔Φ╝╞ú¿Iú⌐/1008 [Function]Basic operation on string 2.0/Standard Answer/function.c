#include <string.h>
int split(char ret[][100], const char str[], const char del) {
    int len = strlen(str);
    int x_index = 0, y_index = 0;
    for (int i = 0; i < len; ++i) {
        if (str[i] != del) {
            ret[x_index][y_index++] = str[i];
        } else {
            ret[x_index++][y_index] = '\0';
            y_index = 0;
        }
    }
    ret[x_index][y_index] = '\0';
    return x_index + 1;
}

void lstrip(char str[], const char del) {
    int len = strlen(str);
    int i = 0;
    while (i < len && str[i] == del)
        ++i;
    memmove(str, str + i, len);
}

void rstrip(char str[], const char del) {
    int len = strlen(str);
    int i = len-1;
    while (i >= 0 && str[i] == del)
        --i;
    str[i+1] = '\0';
}

void strip(char str[], const char del) {
    lstrip(str, del);
    rstrip(str, del);
}
