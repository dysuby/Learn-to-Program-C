# [String]Common prefix

Description

Write a function that returns the common prefix of two strings. For example, the common prefix of "distance" and "disjoint" is "dis". The header of the function is as follows:

char * prefix(const char * const s1, const char * const s2)

If the two strings have no common prefix, the function returns an empty string.
Hint
Don't submit the main() function.