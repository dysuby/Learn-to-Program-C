#ifndef PREFIX_H
#define PREFIX_H
char* prefix(const char* const s1, const char* const s2);
#endif