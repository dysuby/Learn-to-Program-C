#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main()  {
  char mess[103];
  int i, times = 1, j;
  mess[100] = 'a';
  mess[101] = 'a';
  mess[102] = 'a';
  scanf("%s", mess);
  for (i = 0; i < strlen(mess); ++i) {
    if (!isdigit(mess[i])) {
      if (isdigit(mess[i + 1]) && !isdigit(mess[i + 2])) {
        if (mess[i + 1] - 48 > 7) 
          times = (mess[i + 1] - 48) % 7 + 1;
        else
          times = mess[i + 1] - 48;
        for (j = 1; j <= times; ++j)
          printf("%c", mess[i]);
      } else if (isdigit(mess[i + 1]) && isdigit(mess[i + 2]) && !isdigit(mess[i + 3])) {
          times = ((mess[i + 1] - 48) * 10 + (mess[i + 2]) - 48) % 7 + 1;
          for (j = 1; j <= times; ++j)
          printf("%c", mess[i]);
      } else if (isdigit(mess[i + 1]) && isdigit(mess[i + 2]) && isdigit(mess[i + 3])) {
          times = ((mess[i + 1] - 48) * 100 + (mess[i + 2] - 48) * 10 + mess[i + 3] - 48) % 7 + 1;
          for (j = 1; j <= times; ++j)
          printf("%c", mess[i]);
      } else if (!isdigit(mess[i + 1])) {
          printf("%c", mess[i]);
      }
    }
  }
  return 0;
}  