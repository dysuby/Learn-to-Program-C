# [2016 C Midterm A] Simple Geometry

# Desciption

We all know the length of side of a square is always longer than the radius（半径） of a circle when the square and the circle have the same area.

Now give you a **double-type** number which is the area of square and circle.  
You task is to calculate the length of side of square and the radius of the circle, and area of the circumscribed circle（外接圆） of the square.  

You must use the PI with the value 3.1415926  
The Output contains two number rounded to three decimal places. The first is the length of side, the second is the radius, the last is the area of circumscribed circle.  

# Sample Input
```
2.0
```

# Sample Output
```
1.414 0.798 3.142

```

