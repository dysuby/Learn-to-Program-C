# [2016 C Midterm A] Decimal To Other

# Decimal To Other

## Problem

Given a number `n` (2 <= n <= 10) representing the **number system**.

For example, `2` represents the **binary system**, `8` represents the **octal system**.

Given a decimal number, output it in that number system in **inverse order**.

### Sample Input 1

```
2
16
```

### Sample Output 1

```
00001

```

### Sample Input 2

```
3
26
```

### Sample Output 2

```
222

```
