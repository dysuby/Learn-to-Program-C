# [Basic I/O] Triangle I

# Description

Your task is to write a program to output the following image:
```
*..
**.
***
```

# Input

No input.

# Output

As mentioned above.

# Sample Output

```
*..
**.
***
```