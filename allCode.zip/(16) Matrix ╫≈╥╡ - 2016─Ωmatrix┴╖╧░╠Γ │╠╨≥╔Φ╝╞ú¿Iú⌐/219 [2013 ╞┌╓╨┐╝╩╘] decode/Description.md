# [2013 期中考试] decode

## Description:

There is a string which is coded into a password. The rules of the coding is:

A→Z      a→z

B→Y      b→y

C→X      c→x

D→W     d→w

E→V      e→v

......

Please design a program to decode such strings（the lenth of string is less than 80）.

 

有一行字符串按以下规律被译成密码：

A→Z      a→z

B→Y      b→y

C→X      c→x

D→W     d→w

E→V      e→v

......

请设计程序解码这类字符串(长度小于80)。


## Hint:

Make use of ASCII and find the rules in it.
