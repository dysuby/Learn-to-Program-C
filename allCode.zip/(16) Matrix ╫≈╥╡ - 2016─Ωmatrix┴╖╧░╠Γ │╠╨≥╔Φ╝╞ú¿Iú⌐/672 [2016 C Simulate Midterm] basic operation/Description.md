# [2016 C Simulate Midterm] basic operation

Input two integers a and b (0 <= a, b <= 200),please output the result in each line:
a+b
a-b
a*b
a/b (keep the first two digits after the decimal point),If b is equal to 0, output "Error"
the square root of a (keep the first two digits after the decimal point)
 

For example

[Input]
```
10 7
```
 

[Output]
```
17
3
70
1.43
3.16
```
 

[Input]
```
3 0
```

[Output]
```
3
3
0
Error
1.73
```

