# [Conditions] piecewise function

# Description
 
 编程求下列分段函数的值：
 
![](https://github.com/niuguangyu/pic/raw/master/3_1.jpg)

# Input

 一个实数x

# Output

 函数f(x)的值，结果保留到小数点后两位

# Sample Input

```
-2
```
# Sample Output

```
-1.00
```