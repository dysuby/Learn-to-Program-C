# [2013 期中考试] standar

## Description

Standard deviation is the square root of the variance.

Variance formula is   $ S^2= ((x1-x)^2 +(x2-x)^2 +......\frac{(xn-x)^2)}{n}$,  When $x=\frac{(x1+x2+...+xn)}{n} $.

And standard deviation  $S=\sqrt{(S^2)}$.

Now there are n numbers x1,x2, ... xn.(n<=100, x1,x2,...xn are positive integers and not more than 1000)

Please determine the standard deviantion.
Input fumula

Two lines. The first line has a number n.And the second line has n numbers x1,x2...xn.
Output fomula

One number,standard deviation, results 4 decimal places.

### Sample input
```
5
2 4 6 8 10
```

### Sample output
```
2.8284
```
