# [Loop]Find the first prime number

# Description
 寻找指定范围内的第一个素数。
# Input
输入为两个整数n, m(1 <= n < m <= 10000)

# Output
输出[n, m]内第一个素数， 若该范围内不存在素数，则输出none。
# Sample Input 1
 
```
10 20
```

# Sample Output 1

```
11
```

# Sample Input 2

```
90 96
```

# Sample Output 2

```
none
```